module CBS

    toolbar = UI::Toolbar.new(" CadBox Tool")
	 
	 cmd = UI::Command.new("橱柜主体制作") {self.wedi}
     cmd.small_icon = "webtool/icon/cbs.png"
     cmd.large_icon = "webtool/icon/cbsb.png"
     cmd.tooltip = "橱柜主体制作"
     cmd.menu_text = "橱柜主体制作"
	 toolbar = toolbar.add_item cmd 
	 toolbar.show
	 
	 cmd1 = UI::Command.new("橱柜局部制作") {self.wedib}
     cmd1.small_icon = "webtool/icon/macbsb.png"
     cmd1.large_icon = "webtool/icon/macbs.png"
     cmd1.tooltip = "橱柜局部制作"
     cmd1.menu_text = "橱柜局部制作"
	 toolbar1 = toolbar.add_item cmd1 
	 toolbar1.show
	 
	 cmd3 = UI::Command.new("系统") {self.help}
     cmd3.small_icon = "webtool/icon/help.png"
     cmd3.large_icon = "webtool/icon/helpb.png"
     cmd3.tooltip = "帮助"
     cmd3.menu_text = "帮助"
	 toolbar3 = toolbar.add_item cmd3	 
	 toolbar3.show
	 
	 cmd2 = UI::Command.new("版本说明") {self.impres15}
     cmd2.small_icon = "webtool/icon/inf.png"
     cmd2.large_icon = "webtool/icon/infb.png"
     cmd2.tooltip = "版本说明 "
     cmd2.menu_text = "版本说明"
	 toolbar2 = toolbar.add_item cmd2	 
	 toolbar2.show
	 
	file_loaded('bar15.rb')

end

